#include<iostream>
using namespace std;
int main(){
    cout << "Answer: A" << endl;
   int n[3];

   cout <<"Enter number: "<<endl;
   for(int i=0; i<3; i++){
    cin >> n[i];
   }

   int sum=0;
   for(int i=0; i<3; i++){
    sum= sum + n[i];
   }

   float averange;
   averange = sum/3;
   cout << "The resuult is: "<< averange << endl;

   cout <<"Answer: B" <<endl;
   int data[] = {10, 20, 30, 40, 50};
   int m=5;
   for(int i=0; i<5; i++){
    cout << data[i] << " ";
   }

   cout<<"Answer: C" <<endl;
   int set[5];
   cout << "Enter number: " <<endl;
   for(int i=0; i<5; i++){
    cin >> set[i];
   }
   int max = set[0];
   int min = set[0];
   for (int i=0; i<5; i++){
    if(min > set[i]){
        min = set[i];
    }
    if(max < set[i]){
        max = set[i];
    }
   }
   cout << "The minimum number is: " <<min <<endl;
   cout << "The maximum number is: " <<max <<endl;

   cout << "Answer D" <<endl;
   int need[5] = {12, 23, 34, 45, 56};
   cout << "An array element at position 3 is: "<<need[3] << endl;

   cout << "Answer: E " <<endl;
   int p;
   
   cout <<"Enter size of p: " <<endl;
   cin >> p;
   int datas[p];
   cout <<"Enter number: "<<endl;
   for(int i=0; i<p; i++){
    cin>> datas[i];
   }
   
   int k;
   bool f = false;
   cout << "Enter data To research: ";
   cin >> k;
   
   for(int i=0; i<p; i++){
    if(datas[i] == k){
        cout << "Your Data was founded: "<< datas[i] <<endl;
        f = true;
        break;
    }
   }
   
   if(!f){
    cout <<"Your Data not founded!" <<endl;
   }
   return 0;
}

