#include<iostream>
using namespace std;
 class Rectangle {
 private:
      int length;
      int width;

 public:
     void input(){
       cout <<"input width: ";
       cin >>width;

       cout <<"input length: ";
       cin >>length;


     }
     float findArea(int length,int width){
           int result=length*width;
           return result;
     }
     void showDetail(){
           cout << "width: " <<width <<endl;
           cout << "length: " <<length <<endl;
           cout << "rectangle's area: " <<findArea(length,width)<<endl;
     }


 };
int main () {
    Rectangle R;
    R.input();
    R.showDetail();




return 0;
}

