#include<iostream>
using namespace std;
class BankAccount{
    private:
        int accountNumber;
        float balance;

    public:
    BankAccount(int accountNumber_, float balance_){
        accountNumber = accountNumber_;
        balance = balance_;
    }

    void deposit( float amount){
        balance = balance + amount;
        cout <<"Deposit is: $"; cin >> amount;
    }

    void withdraw(float amount){
        if(balance >= amount){
            balance = balance - amount;
            cout << "Withdraw: $" << amount <<endl;
        }else{
            cout <<"Your money is not enough!!!"<<endl;
        }
    }

    void desplay(){
        cout <<"Your AccountNumber is: " << accountNumber << endl;
        cout <<"Your balance mone is : " << balance <<  endl;
    }
};

int main(){
    BankAccount a1(1234, 1000);
    a1.desplay();
    cout <<endl;

    a1.deposit();
    a1.desplay();
    cout << endl;

    a1.withdraw();
    a1.desplay();
    return 0;
}
