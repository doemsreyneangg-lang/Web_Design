#include<iostream>
using namespace std;
float computeA(int n);
float computeB(int n); 
float computeC(int n); 
float computeA(int n){
    float sum=0;
    for (int i=1; i<=n; i++){
        sum= sum + i;
    }
    return sum;
}
float computeB(int n){
    float sum=0;
    for(int i=1; i<=n; i++){
        sum= sum + i*i;
    }
    return sum;
}
float computeC(int n){
    float sum=0;
    for(int i=1; i<=n; i++){
        sum= sum+ 1.0/i;
    }
    return sum;
}
int main(){
    int n;
    cout << "Enter number n: ";
    cin >> n;
    cout <<"a. " << computeA(n) <<endl;
    cout <<"b. " << computeB(n) <<endl;
    cout <<"c. " << computeC(n) << endl;
    return 0;
}

