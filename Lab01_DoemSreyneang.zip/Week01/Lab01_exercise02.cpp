#include <iostream>
using namespace std;
int main(){
    int number[10];
    int evenCount =0;
    cout << "Enter 10 numbers: "<<endl;
    for(int i=0; i<10; i++){
        cin >> number[i];
    }
    cout << "Numbers in reverse order: ";
    for(int i=9; i>=0; i--){
        cout <<number[i] << " ";
    }
    for(int i=0; i<10; i++){
        if(number[i]%2==0){
            evenCount++;
        }
    }
    cout << "\nNumber of even is "<< evenCount << endl;
    return 0;
}


