#include<iostream>
using namespace std;
class Book {
    private:
        string title;
        string author;
    public:
        void setDetails(){
            cout <<"Enter Book title is: "; cin >> title ;
            cout <<"Enter Book author is: "; cin >> author;
        }
        void displayDetails(){
            cout <<"The Book title name is: " << title << endl;
            cout <<"The Book author name is:" << author << endl;
        }
};
int main(){
    Book b1, b2;
    b1.setDetails();
    b1.displayDetails();
    cout <<endl;
    return 0;
}

