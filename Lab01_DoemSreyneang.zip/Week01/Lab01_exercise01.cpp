#include <iostream>
using namespace std;
int main(){
    cout << "__________________________________________________________";
    cout << "\n\nWelcome to Data Structure and Programming class";
    cout << "\n\n___________________________________________________________";
    cout << "\nMy name is ___ I am currently a year 2's student from group department."
        <<"\nI am so excited to start my class in this term."<<endl;
    return 0;
}


